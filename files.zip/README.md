# Multimodal Construction Intelligence Platform

AI decision-support app for construction sites (Skill Wallet Capstone Project 1).

## Features
- **Safety & PPE audit**: upload a site photo; get a safety score, PPE checklist, hazards with severity and remedies (JSON report download).
- **Crack diagnostics**: defect type, estimated width, severity, root causes, repairs, urgency.
- **Planning & valuation**: project budget, capital spent, asset valuation in INR (Lakh/Crore), steel/cement estimates, progress bar, AI concept rendering (Pollinations).
- **Site assistant**: weather-aware advisories (High Wind, Heavy Rain, Extreme Heat, Normal) and a multi-turn chatbot.
- **Demo mode**: runs without an API key using sample outputs.

## Tech stack
Python 3.9+, Streamlit, Google Gemini (google-genai), Pillow, Pollinations API, JSON data contracts.

## Run locally
```bash
pip install -r requirements.txt
streamlit run app.py
```
Paste a Gemini API key in the sidebar, or set `GEMINI_API_KEY` in `.streamlit/secrets.toml`.

## Deploy
Push to GitHub, then create an app at share.streamlit.io (main file: `app.py`). Add `GEMINI_API_KEY` under Secrets for live AI.

## Known limitations
- Valuation and material figures are rule-of-thumb estimates, not quotations.
- AI findings are advisory and must be verified by a qualified engineer.
- Without an API key the app shows sample (demo) outputs.
